# Exercício 003 — API de E-commerce Clone Amazon + Interface Gráfica

Projeto desenvolvido em **Node.js com Express**, usando rotas separadas, validações, middlewares, cookies, sessões e uma interface gráfica simples para testar os fluxos principais.

## Funcionalidades implementadas

- Cadastro, login, logout e perfil de usuário.
- Sessão com `express-session`, armazenando `userId`.
- Produtos com filtros por categoria, preço mínimo, preço máximo e busca por nome.
- Rotas protegidas para carrinho, pedidos e avaliações.
- Rotas administrativas para criar, editar e remover produtos.
- Carrinho de compras com adicionar, atualizar, remover e visualizar itens.
- Checkout convertendo carrinho em pedido.
- Histórico e detalhes de pedidos.
- Avaliações de produtos com nota de 1 a 5 e comentário.
- Bloqueio de avaliação duplicada no mesmo produto pelo mesmo usuário.
- Cookies para preferências de tema e moeda.
- Conversão simulada de preços por moeda.
- Middleware global de erro.
- Interface gráfica em HTML, CSS e JavaScript puro.

## Tecnologias

- Node.js
- Express
- express-session
- cookie-parser
- express-validator
- bcryptjs
- HTML, CSS e JavaScript

## Como rodar o projeto

```bash
npm install
npm start
```

Depois abra no navegador:

```text
http://localhost:3000
```

## Usuário administrador inicial

Use este login para testar as rotas administrativas:

```text
E-mail: admin@clone.com
Senha: admin123
```

## Usuário comum inicial

```text
E-mail: cliente@clone.com
Senha: cliente123
```

## Principais endpoints

### Usuários

```http
POST /api/users/register
POST /api/users/login
POST /api/users/logout
GET  /api/users/profile
PUT  /api/users/profile
```

### Produtos

```http
GET    /api/products
GET    /api/products/:id
POST   /api/products
PUT    /api/products/:id
DELETE /api/products/:id
```

### Carrinho

```http
GET    /api/cart
POST   /api/cart/items
PUT    /api/cart/items/:productId
DELETE /api/cart/items/:productId
```

### Pedidos

```http
POST /api/orders/checkout
GET  /api/orders
GET  /api/orders/:id
```

### Avaliações

```http
POST /api/products/:productId/reviews
GET  /api/products/:productId/reviews
```

### Preferências

```http
POST /api/preferences
```

## Como entregar no GitHub

Crie um repositório público no GitHub e rode estes comandos dentro da pasta do projeto:

```bash
git init
git add .
git commit -m "Exercicio 003 API Ecommerce"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/exercicio-003-ecommerce-api.git
git push -u origin main
```

No GitHub, confira se o repositório está como **Public**.

## Observação

Os dados são mockados em memória, então ao reiniciar o servidor os dados criados durante o teste voltam ao estado inicial.
