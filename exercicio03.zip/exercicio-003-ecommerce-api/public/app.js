const resultBox = document.getElementById("resultBox");
const statusText = document.getElementById("statusText");
const productsBox = document.getElementById("products");
const cartBox = document.getElementById("cart");
const ordersBox = document.getElementById("orders");
const profileBox = document.getElementById("profileBox");

function showResult(data) {
  resultBox.textContent = JSON.stringify(data, null, 2);
}

async function api(path, options = {}) {
  const config = {
    credentials: "include",
    headers: {
      "Content-Type": "application/json"
    },
    ...options
  };

  const response = await fetch(path, config);
  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    showResult(data);
    throw new Error(data.message || "Erro na requisição");
  }

  showResult(data);
  return data;
}

function formatPrice(product) {
  const currency = product.moeda || "BRL";

  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency
  }).format(product.preco);
}

async function checkStatus() {
  try {
    const data = await api("/api/health");
    statusText.textContent = data.message;
  } catch (error) {
    statusText.textContent = "API indisponível";
  }
}

async function loadPreferences() {
  try {
    const data = await api("/api/preferences");
    if (data.preferences.theme === "dark") {
      document.body.classList.add("dark");
    } else {
      document.body.classList.remove("dark");
    }
  } catch (error) {}
}

async function loadProducts(query = "") {
  const data = await api(`/api/products${query}`);
  productsBox.innerHTML = "";

  data.products.forEach((product) => {
    const card = document.createElement("article");
    card.className = "product-card";

    card.innerHTML = `
      <img src="${product.imagem}" alt="${product.nome}">
      <div class="content">
        <h3>${product.nome}</h3>
        <p>${product.descricao}</p>
        <p><strong>Categoria:</strong> ${product.categoria}</p>
        <p><strong>Estoque:</strong> ${product.estoque}</p>
        <p class="price">${formatPrice(product)}</p>
        <button onclick="addToCart(${product.id})">Adicionar ao carrinho</button>

        <div class="review-box">
          <select id="nota-${product.id}">
            <option value="5">5 estrelas</option>
            <option value="4">4 estrelas</option>
            <option value="3">3 estrelas</option>
            <option value="2">2 estrelas</option>
            <option value="1">1 estrela</option>
          </select>
          <input id="comentario-${product.id}" placeholder="Comentário da avaliação">
          <button onclick="createReview(${product.id})">Avaliar produto</button>
          <button onclick="loadReviews(${product.id})">Ver avaliações</button>
          <div id="reviews-${product.id}"></div>
        </div>
      </div>
    `;

    productsBox.appendChild(card);
  });
}

async function addToCart(productId) {
  try {
    await api("/api/cart/items", {
      method: "POST",
      body: JSON.stringify({
        productId,
        quantidade: 1
      })
    });
    await loadCart();
  } catch (error) {
    alert(error.message);
  }
}

async function loadCart() {
  try {
    const data = await api("/api/cart");
    cartBox.innerHTML = "";

    if (data.cart.items.length === 0) {
      cartBox.innerHTML = "<p>Carrinho vazio.</p>";
      return;
    }

    data.cart.items.forEach((item) => {
      const div = document.createElement("div");
      div.className = "cart-item";
      div.innerHTML = `
        <strong>${item.produto.nome}</strong>
        <p>Quantidade: ${item.quantidade}</p>
        <p>Subtotal: R$ ${item.subtotal.toFixed(2)}</p>
        <input id="qty-${item.productId}" type="number" min="1" value="${item.quantidade}">
        <button onclick="updateCartItem(${item.productId})">Atualizar</button>
        <button onclick="removeCartItem(${item.productId})">Remover</button>
      `;
      cartBox.appendChild(div);
    });

    const total = document.createElement("p");
    total.innerHTML = `<strong>Total: R$ ${data.cart.total.toFixed(2)}</strong>`;
    cartBox.appendChild(total);
  } catch (error) {
    alert(error.message);
  }
}

async function updateCartItem(productId) {
  const quantidade = Number(document.getElementById(`qty-${productId}`).value);

  try {
    await api(`/api/cart/items/${productId}`, {
      method: "PUT",
      body: JSON.stringify({ quantidade })
    });
    await loadCart();
  } catch (error) {
    alert(error.message);
  }
}

async function removeCartItem(productId) {
  try {
    await api(`/api/cart/items/${productId}`, {
      method: "DELETE"
    });
    await loadCart();
  } catch (error) {
    alert(error.message);
  }
}

async function checkout() {
  try {
    await api("/api/orders/checkout", {
      method: "POST"
    });
    await loadCart();
    await loadOrders();
    await loadProducts();
  } catch (error) {
    alert(error.message);
  }
}

async function loadOrders() {
  try {
    const data = await api("/api/orders");
    ordersBox.innerHTML = "";

    if (data.orders.length === 0) {
      ordersBox.innerHTML = "<p>Nenhum pedido encontrado.</p>";
      return;
    }

    data.orders.forEach((order) => {
      const div = document.createElement("div");
      div.className = "order-item";
      div.innerHTML = `
        <strong>Pedido #${order.id}</strong>
        <p>Status: ${order.status}</p>
        <p>Total: R$ ${order.total.toFixed(2)}</p>
        <p>Data: ${new Date(order.data).toLocaleString("pt-BR")}</p>
      `;
      ordersBox.appendChild(div);
    });
  } catch (error) {
    alert(error.message);
  }
}

async function createReview(productId) {
  const nota = Number(document.getElementById(`nota-${productId}`).value);
  const comentario = document.getElementById(`comentario-${productId}`).value;

  try {
    await api(`/api/products/${productId}/reviews`, {
      method: "POST",
      body: JSON.stringify({ nota, comentario })
    });
    await loadReviews(productId);
  } catch (error) {
    alert(error.message);
  }
}

async function loadReviews(productId) {
  try {
    const data = await api(`/api/products/${productId}/reviews`);
    const box = document.getElementById(`reviews-${productId}`);

    if (data.reviews.length === 0) {
      box.innerHTML = "<p>Sem avaliações.</p>";
      return;
    }

    box.innerHTML = data.reviews
      .map(
        (review) => `
          <div class="review-item">
            <strong>${review.nota}/5</strong>
            <p>${review.comentario}</p>
            <small>${review.usuario}</small>
          </div>
        `
      )
      .join("");
  } catch (error) {
    alert(error.message);
  }
}

document.getElementById("registerForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = new FormData(event.target);

  try {
    await api("/api/users/register", {
      method: "POST",
      body: JSON.stringify(Object.fromEntries(form))
    });
    event.target.reset();
  } catch (error) {
    alert(error.message);
  }
});

document.getElementById("loginForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = new FormData(event.target);

  try {
    await api("/api/users/login", {
      method: "POST",
      body: JSON.stringify(Object.fromEntries(form))
    });
    await loadCart();
  } catch (error) {
    alert(error.message);
  }
});

document.getElementById("logoutBtn").addEventListener("click", async () => {
  try {
    await api("/api/users/logout", {
      method: "POST"
    });
    profileBox.textContent = "";
    cartBox.innerHTML = "";
    ordersBox.innerHTML = "";
  } catch (error) {
    alert(error.message);
  }
});

document.getElementById("loadProfileBtn").addEventListener("click", async () => {
  try {
    const data = await api("/api/users/profile");
    profileBox.textContent = JSON.stringify(data.user, null, 2);
  } catch (error) {
    alert(error.message);
  }
});

document.getElementById("preferencesForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = new FormData(event.target);

  try {
    await api("/api/preferences", {
      method: "POST",
      body: JSON.stringify(Object.fromEntries(form))
    });
    await loadPreferences();
    await loadProducts();
  } catch (error) {
    alert(error.message);
  }
});

document.getElementById("filterForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const params = new URLSearchParams();
  const form = new FormData(event.target);

  for (const [key, value] of form.entries()) {
    if (value) {
      params.set(key, value);
    }
  }

  const query = params.toString() ? `?${params.toString()}` : "";
  await loadProducts(query);
});

document.getElementById("productForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = new FormData(event.target);
  const data = Object.fromEntries(form);

  data.preco = Number(data.preco);
  data.estoque = Number(data.estoque);

  if (!data.imagem) {
    delete data.imagem;
  }

  try {
    await api("/api/products", {
      method: "POST",
      body: JSON.stringify(data)
    });
    event.target.reset();
    await loadProducts();
  } catch (error) {
    alert(error.message);
  }
});

document.getElementById("loadProductsBtn").addEventListener("click", () => loadProducts());
document.getElementById("loadCartBtn").addEventListener("click", loadCart);
document.getElementById("checkoutBtn").addEventListener("click", checkout);
document.getElementById("loadOrdersBtn").addEventListener("click", loadOrders);

checkStatus();
loadPreferences();
loadProducts();
