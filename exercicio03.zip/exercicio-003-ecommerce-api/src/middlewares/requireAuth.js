const { users } = require("../data/store");

function requireAuth(req, res, next) {
  if (!req.session || !req.session.userId) {
    return res.status(401).json({
      message: "Unauthorized: faça login para acessar esta rota"
    });
  }

  const user = users.find((item) => item.id === req.session.userId);

  if (!user) {
    return res.status(401).json({
      message: "Unauthorized: usuário da sessão não encontrado"
    });
  }

  req.user = user;
  next();
}

module.exports = requireAuth;
