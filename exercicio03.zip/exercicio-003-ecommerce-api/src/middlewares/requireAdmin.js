function requireAdmin(req, res, next) {
  if (!req.user || req.user.isAdmin !== true) {
    return res.status(403).json({
      message: "Forbidden: apenas administradores podem acessar esta rota"
    });
  }

  next();
}

module.exports = requireAdmin;
