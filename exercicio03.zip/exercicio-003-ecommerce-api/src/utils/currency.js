const rates = {
  BRL: 1,
  USD: 0.19,
  EUR: 0.17
};

function readPreferences(req) {
  const defaultPreferences = {
    theme: "light",
    currency: "BRL"
  };

  if (!req.cookies || !req.cookies.preferences) {
    return defaultPreferences;
  }

  try {
    return {
      ...defaultPreferences,
      ...JSON.parse(req.cookies.preferences)
    };
  } catch (error) {
    return defaultPreferences;
  }
}

function convertPrice(price, currency) {
  const selectedCurrency = rates[currency] ? currency : "BRL";
  return Number((price * rates[selectedCurrency]).toFixed(2));
}

function productWithCurrency(product, req) {
  const preferences = readPreferences(req);
  const currency = preferences.currency || "BRL";

  return {
    ...product,
    precoOriginalBRL: product.preco,
    preco: convertPrice(product.preco, currency),
    moeda: currency
  };
}

module.exports = {
  rates,
  readPreferences,
  convertPrice,
  productWithCurrency
};
