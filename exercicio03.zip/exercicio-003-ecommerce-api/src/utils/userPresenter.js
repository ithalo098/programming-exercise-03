function publicUser(user) {
  if (!user) {
    return null;
  }

  return {
    id: user.id,
    nome: user.nome,
    email: user.email,
    endereco: user.endereco,
    isAdmin: user.isAdmin
  };
}

module.exports = publicUser;
