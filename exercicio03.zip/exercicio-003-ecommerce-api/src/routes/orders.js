const express = require("express");
const { param } = require("express-validator");
const requireAuth = require("../middlewares/requireAuth");
const validate = require("../middlewares/validate");
const ordersController = require("../controllers/ordersController");

const router = express.Router();

router.use(requireAuth);

router.post("/checkout", ordersController.checkout);

router.get("/", ordersController.listOrders);

router.get(
  "/:id",
  [
    param("id")
      .isInt({ min: 1 })
      .withMessage("ID do pedido inválido")
  ],
  validate,
  ordersController.getOrderById
);

module.exports = router;
