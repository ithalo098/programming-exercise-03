const express = require("express");
const { body, param } = require("express-validator");
const validate = require("../middlewares/validate");
const requireAuth = require("../middlewares/requireAuth");
const cartController = require("../controllers/cartController");

const router = express.Router();

router.use(requireAuth);

router.get("/", cartController.getCart);

router.post(
  "/items",
  [
    body("productId")
      .isInt({ min: 1 })
      .withMessage("O productId deve ser válido"),
    body("quantidade")
      .isInt({ min: 1 })
      .withMessage("A quantidade deve ser maior que zero")
  ],
  validate,
  cartController.addItem
);

router.put(
  "/items/:productId",
  [
    param("productId")
      .isInt({ min: 1 })
      .withMessage("O productId deve ser válido"),
    body("quantidade")
      .isInt({ min: 1 })
      .withMessage("A quantidade deve ser maior que zero")
  ],
  validate,
  cartController.updateItem
);

router.delete(
  "/items/:productId",
  [
    param("productId")
      .isInt({ min: 1 })
      .withMessage("O productId deve ser válido")
  ],
  validate,
  cartController.removeItem
);

module.exports = router;
