const express = require("express");
const { body, param } = require("express-validator");
const validate = require("../middlewares/validate");
const requireAuth = require("../middlewares/requireAuth");
const requireAdmin = require("../middlewares/requireAdmin");
const productsController = require("../controllers/productsController");

const router = express.Router();

const productCreateValidation = [
  body("nome")
    .trim()
    .notEmpty()
    .withMessage("O nome do produto é obrigatório"),
  body("descricao")
    .trim()
    .notEmpty()
    .withMessage("A descrição é obrigatória"),
  body("preco")
    .isFloat({ gt: 0 })
    .withMessage("O preço deve ser positivo"),
  body("categoria")
    .trim()
    .notEmpty()
    .withMessage("A categoria é obrigatória"),
  body("estoque")
    .isInt({ min: 0 })
    .withMessage("O estoque deve ser zero ou positivo"),
  body("imagem")
    .optional()
    .isURL()
    .withMessage("A imagem deve ser uma URL válida")
];

const productUpdateValidation = [
  param("id")
    .isInt({ min: 1 })
    .withMessage("ID inválido"),
  body("nome")
    .optional()
    .trim()
    .notEmpty()
    .withMessage("O nome não pode ficar vazio"),
  body("descricao")
    .optional()
    .trim()
    .notEmpty()
    .withMessage("A descrição não pode ficar vazia"),
  body("preco")
    .optional()
    .isFloat({ gt: 0 })
    .withMessage("O preço deve ser positivo"),
  body("categoria")
    .optional()
    .trim()
    .notEmpty()
    .withMessage("A categoria não pode ficar vazia"),
  body("estoque")
    .optional()
    .isInt({ min: 0 })
    .withMessage("O estoque deve ser zero ou positivo"),
  body("imagem")
    .optional()
    .isURL()
    .withMessage("A imagem deve ser uma URL válida")
];

router.get("/", productsController.listProducts);

router.get(
  "/:id",
  [
    param("id")
      .isInt({ min: 1 })
      .withMessage("ID inválido")
  ],
  validate,
  productsController.getProductById
);

router.post(
  "/",
  requireAuth,
  requireAdmin,
  productCreateValidation,
  validate,
  productsController.createProduct
);

router.put(
  "/:id",
  requireAuth,
  requireAdmin,
  productUpdateValidation,
  validate,
  productsController.updateProduct
);

router.delete(
  "/:id",
  requireAuth,
  requireAdmin,
  [
    param("id")
      .isInt({ min: 1 })
      .withMessage("ID inválido")
  ],
  validate,
  productsController.deleteProduct
);

module.exports = router;
