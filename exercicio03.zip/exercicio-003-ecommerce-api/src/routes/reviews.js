const express = require("express");
const { body, param } = require("express-validator");
const validate = require("../middlewares/validate");
const requireAuth = require("../middlewares/requireAuth");
const reviewsController = require("../controllers/reviewsController");

const router = express.Router();

router.post(
  "/:productId/reviews",
  requireAuth,
  [
    param("productId")
      .isInt({ min: 1 })
      .withMessage("ID do produto inválido"),
    body("nota")
      .isInt({ min: 1, max: 5 })
      .withMessage("A nota deve estar entre 1 e 5"),
    body("comentario")
      .trim()
      .notEmpty()
      .withMessage("O comentário é obrigatório")
  ],
  validate,
  reviewsController.createReview
);

router.get(
  "/:productId/reviews",
  [
    param("productId")
      .isInt({ min: 1 })
      .withMessage("ID do produto inválido")
  ],
  validate,
  reviewsController.listReviews
);

module.exports = router;
