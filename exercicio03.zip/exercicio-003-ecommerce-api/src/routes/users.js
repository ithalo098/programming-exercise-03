const express = require("express");
const { body } = require("express-validator");
const { users } = require("../data/store");
const validate = require("../middlewares/validate");
const requireAuth = require("../middlewares/requireAuth");
const asyncHandler = require("../utils/asyncHandler");
const usersController = require("../controllers/usersController");

const router = express.Router();

router.post(
  "/register",
  [
    body("nome")
      .trim()
      .notEmpty()
      .withMessage("O nome é obrigatório"),
    body("email")
      .isEmail()
      .withMessage("Informe um e-mail válido")
      .custom((email) => {
        const exists = users.some((user) => user.email === email.toLowerCase());

        if (exists) {
          throw new Error("E-mail já cadastrado");
        }

        return true;
      }),
    body("senha")
      .isLength({ min: 6 })
      .withMessage("A senha deve ter no mínimo 6 caracteres"),
    body("endereco")
      .trim()
      .notEmpty()
      .withMessage("O endereço é obrigatório")
  ],
  validate,
  asyncHandler(usersController.register)
);

router.post(
  "/login",
  [
    body("email")
      .isEmail()
      .withMessage("Informe um e-mail válido"),
    body("senha")
      .notEmpty()
      .withMessage("A senha é obrigatória")
  ],
  validate,
  asyncHandler(usersController.login)
);

router.post("/logout", usersController.logout);

router.get("/profile", requireAuth, usersController.profile);

router.put(
  "/profile",
  requireAuth,
  [
    body("nome")
      .optional()
      .trim()
      .notEmpty()
      .withMessage("O nome não pode ficar vazio"),
    body("endereco")
      .optional()
      .trim()
      .notEmpty()
      .withMessage("O endereço não pode ficar vazio"),
    body("senha")
      .optional()
      .isLength({ min: 6 })
      .withMessage("A senha deve ter no mínimo 6 caracteres")
  ],
  validate,
  usersController.updateProfile
);

module.exports = router;
