const express = require("express");
const { body } = require("express-validator");
const validate = require("../middlewares/validate");
const preferencesController = require("../controllers/preferencesController");

const router = express.Router();

router.get("/", preferencesController.getPreferences);

router.post(
  "/",
  [
    body("theme")
      .optional()
      .isIn(["light", "dark"])
      .withMessage("O tema deve ser light ou dark"),
    body("currency")
      .optional()
      .isIn(["BRL", "USD", "EUR"])
      .withMessage("A moeda deve ser BRL, USD ou EUR")
  ],
  validate,
  preferencesController.setPreferences
);

module.exports = router;
