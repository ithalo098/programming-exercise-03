const bcrypt = require("bcryptjs");

const users = [
  {
    id: 1,
    nome: "Administrador",
    email: "admin@clone.com",
    senhaHash: bcrypt.hashSync("admin123", 10),
    endereco: "Rua Admin, 100",
    isAdmin: true
  },
  {
    id: 2,
    nome: "Cliente Teste",
    email: "cliente@clone.com",
    senhaHash: bcrypt.hashSync("cliente123", 10),
    endereco: "Rua Cliente, 200",
    isAdmin: false
  }
];

const products = [
  {
    id: 1,
    nome: "Notebook Ultra Pro",
    descricao: "Notebook rápido para trabalho e estudos.",
    preco: 4299.9,
    categoria: "eletronicos",
    estoque: 8,
    imagem: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=700"
  },
  {
    id: 2,
    nome: "Smartphone Max",
    descricao: "Celular moderno com câmera de alta qualidade.",
    preco: 2499.9,
    categoria: "eletronicos",
    estoque: 15,
    imagem: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=700"
  },
  {
    id: 3,
    nome: "Fone Bluetooth",
    descricao: "Fone sem fio com bateria de longa duração.",
    preco: 199.9,
    categoria: "acessorios",
    estoque: 30,
    imagem: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=700"
  },
  {
    id: 4,
    nome: "Cadeira Gamer",
    descricao: "Cadeira confortável para setup gamer.",
    preco: 899.9,
    categoria: "moveis",
    estoque: 6,
    imagem: "https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?w=700"
  },
  {
    id: 5,
    nome: "Livro JavaScript Essencial",
    descricao: "Livro para aprender JavaScript do zero.",
    preco: 79.9,
    categoria: "livros",
    estoque: 20,
    imagem: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=700"
  }
];

const carts = [];
const orders = [];
const reviews = [
  {
    id: 1,
    productId: 1,
    userId: 2,
    nota: 5,
    comentario: "Produto excelente.",
    data: new Date().toISOString()
  }
];

const counters = {
  user: 3,
  product: 6,
  order: 1,
  review: 2
};

function nextId(type) {
  const id = counters[type];
  counters[type] += 1;
  return id;
}

module.exports = {
  users,
  products,
  carts,
  orders,
  reviews,
  nextId
};
