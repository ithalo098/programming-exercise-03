const { products, reviews, users, nextId } = require("../data/store");

function createReview(req, res) {
  const productId = Number(req.params.productId);
  const { nota, comentario } = req.body;

  const product = products.find((item) => item.id === productId);

  if (!product) {
    return res.status(404).json({
      message: "Produto não encontrado"
    });
  }

  const alreadyReviewed = reviews.some(
    (review) => review.productId === productId && review.userId === req.user.id
  );

  if (alreadyReviewed) {
    return res.status(400).json({
      message: "Você já avaliou este produto"
    });
  }

  const review = {
    id: nextId("review"),
    productId,
    userId: req.user.id,
    nota: Number(nota),
    comentario,
    data: new Date().toISOString()
  };

  reviews.push(review);

  res.status(201).json({
    message: "Avaliação criada com sucesso",
    review
  });
}

function listReviews(req, res) {
  const productId = Number(req.params.productId);
  const product = products.find((item) => item.id === productId);

  if (!product) {
    return res.status(404).json({
      message: "Produto não encontrado"
    });
  }

  const productReviews = reviews
    .filter((review) => review.productId === productId)
    .map((review) => {
      const user = users.find((item) => item.id === review.userId);

      return {
        ...review,
        usuario: user ? user.nome : "Usuário removido"
      };
    });

  res.json({
    total: productReviews.length,
    reviews: productReviews
  });
}

module.exports = {
  createReview,
  listReviews
};
