const { products, nextId } = require("../data/store");
const { productWithCurrency } = require("../utils/currency");

function listProducts(req, res) {
  const { category, minPrice, maxPrice, search } = req.query;

  let result = [...products];

  if (category) {
    result = result.filter((product) => product.categoria.toLowerCase() === category.toLowerCase());
  }

  if (minPrice) {
    result = result.filter((product) => product.preco >= Number(minPrice));
  }

  if (maxPrice) {
    result = result.filter((product) => product.preco <= Number(maxPrice));
  }

  if (search) {
    result = result.filter((product) =>
      product.nome.toLowerCase().includes(search.toLowerCase())
    );
  }

  res.json({
    total: result.length,
    products: result.map((product) => productWithCurrency(product, req))
  });
}

function getProductById(req, res) {
  const id = Number(req.params.id);
  const product = products.find((item) => item.id === id);

  if (!product) {
    return res.status(404).json({
      message: "Produto não encontrado"
    });
  }

  res.json({
    product: productWithCurrency(product, req)
  });
}

function createProduct(req, res) {
  const { nome, descricao, preco, categoria, estoque, imagem } = req.body;

  const product = {
    id: nextId("product"),
    nome,
    descricao,
    preco: Number(preco),
    categoria,
    estoque: Number(estoque),
    imagem: imagem || "https://images.unsplash.com/photo-1607082349566-187342175e2f?w=700"
  };

  products.push(product);

  res.status(201).json({
    message: "Produto criado com sucesso",
    product
  });
}

function updateProduct(req, res) {
  const id = Number(req.params.id);
  const product = products.find((item) => item.id === id);

  if (!product) {
    return res.status(404).json({
      message: "Produto não encontrado"
    });
  }

  const { nome, descricao, preco, categoria, estoque, imagem } = req.body;

  if (nome !== undefined) product.nome = nome;
  if (descricao !== undefined) product.descricao = descricao;
  if (preco !== undefined) product.preco = Number(preco);
  if (categoria !== undefined) product.categoria = categoria;
  if (estoque !== undefined) product.estoque = Number(estoque);
  if (imagem !== undefined) product.imagem = imagem;

  res.json({
    message: "Produto atualizado com sucesso",
    product
  });
}

function deleteProduct(req, res) {
  const id = Number(req.params.id);
  const index = products.findIndex((item) => item.id === id);

  if (index === -1) {
    return res.status(404).json({
      message: "Produto não encontrado"
    });
  }

  products.splice(index, 1);

  res.json({
    message: "Produto removido com sucesso"
  });
}

module.exports = {
  listProducts,
  getProductById,
  createProduct,
  updateProduct,
  deleteProduct
};
