const { products, carts, orders, nextId } = require("../data/store");
const { findUserCart, buildCartResponse } = require("./cartController");

function checkout(req, res) {
  const cart = findUserCart(req.user.id);

  if (cart.items.length === 0) {
    return res.status(400).json({
      message: "Carrinho vazio"
    });
  }

  for (const item of cart.items) {
    const product = products.find((entry) => entry.id === item.productId);

    if (!product) {
      return res.status(404).json({
        message: `Produto ${item.productId} não encontrado`
      });
    }

    if (item.quantidade > product.estoque) {
      return res.status(400).json({
        message: `Estoque insuficiente para o produto ${product.nome}`
      });
    }
  }

  const cartResponse = buildCartResponse(cart);

  for (const item of cart.items) {
    const product = products.find((entry) => entry.id === item.productId);
    product.estoque -= item.quantidade;
  }

  const order = {
    id: nextId("order"),
    userId: req.user.id,
    data: new Date().toISOString(),
    status: "finalizado",
    itens: cartResponse.items.map((item) => ({
      productId: item.productId,
      nome: item.produto.nome,
      precoUnitario: item.produto.preco,
      quantidade: item.quantidade,
      subtotal: item.subtotal
    })),
    total: cartResponse.total
  };

  orders.push(order);
  cart.items = [];

  res.status(201).json({
    message: "Compra finalizada com sucesso",
    order
  });
}

function listOrders(req, res) {
  const userOrders = orders.filter((order) => order.userId === req.user.id);

  res.json({
    total: userOrders.length,
    orders: userOrders
  });
}

function getOrderById(req, res) {
  const id = Number(req.params.id);
  const order = orders.find((item) => item.id === id);

  if (!order) {
    return res.status(404).json({
      message: "Pedido não encontrado"
    });
  }

  if (order.userId !== req.user.id) {
    return res.status(403).json({
      message: "Forbidden: este pedido não pertence ao usuário logado"
    });
  }

  res.json({
    order
  });
}

module.exports = {
  checkout,
  listOrders,
  getOrderById
};
