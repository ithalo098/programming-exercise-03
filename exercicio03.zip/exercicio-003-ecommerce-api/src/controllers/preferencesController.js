const { readPreferences } = require("../utils/currency");

function setPreferences(req, res) {
  const currentPreferences = readPreferences(req);

  const preferences = {
    theme: req.body.theme || currentPreferences.theme || "light",
    currency: req.body.currency || currentPreferences.currency || "BRL"
  };

  res.cookie("preferences", JSON.stringify(preferences), {
    maxAge: 1000 * 60 * 60 * 24 * 30,
    sameSite: "lax"
  });

  res.json({
    message: "Preferências salvas em cookie",
    preferences
  });
}

function getPreferences(req, res) {
  res.json({
    preferences: readPreferences(req)
  });
}

module.exports = {
  setPreferences,
  getPreferences
};
