const { products, carts } = require("../data/store");

function findUserCart(userId) {
  let cart = carts.find((item) => item.userId === userId);

  if (!cart) {
    cart = {
      userId,
      items: []
    };
    carts.push(cart);
  }

  return cart;
}

function buildCartResponse(cart) {
  const items = cart.items.map((item) => {
    const product = products.find((entry) => entry.id === item.productId);

    return {
      productId: item.productId,
      quantidade: item.quantidade,
      produto: product || null,
      subtotal: product ? Number((product.preco * item.quantidade).toFixed(2)) : 0
    };
  });

  const total = items.reduce((sum, item) => sum + item.subtotal, 0);

  return {
    userId: cart.userId,
    items,
    total: Number(total.toFixed(2))
  };
}

function getCart(req, res) {
  const cart = findUserCart(req.user.id);

  res.json({
    cart: buildCartResponse(cart)
  });
}

function addItem(req, res) {
  const productId = Number(req.body.productId);
  const quantidade = Number(req.body.quantidade);
  const product = products.find((item) => item.id === productId);

  if (!product) {
    return res.status(404).json({
      message: "Produto não encontrado"
    });
  }

  const cart = findUserCart(req.user.id);
  const existingItem = cart.items.find((item) => item.productId === productId);
  const currentQuantity = existingItem ? existingItem.quantidade : 0;
  const newQuantity = currentQuantity + quantidade;

  if (newQuantity > product.estoque) {
    return res.status(400).json({
      message: "Quantidade solicitada maior que o estoque disponível"
    });
  }

  if (existingItem) {
    existingItem.quantidade = newQuantity;
  } else {
    cart.items.push({
      productId,
      quantidade
    });
  }

  res.status(201).json({
    message: "Item adicionado ao carrinho",
    cart: buildCartResponse(cart)
  });
}

function updateItem(req, res) {
  const productId = Number(req.params.productId);
  const quantidade = Number(req.body.quantidade);
  const product = products.find((item) => item.id === productId);

  if (!product) {
    return res.status(404).json({
      message: "Produto não encontrado"
    });
  }

  if (quantidade > product.estoque) {
    return res.status(400).json({
      message: "Quantidade solicitada maior que o estoque disponível"
    });
  }

  const cart = findUserCart(req.user.id);
  const item = cart.items.find((entry) => entry.productId === productId);

  if (!item) {
    return res.status(404).json({
      message: "Item não encontrado no carrinho"
    });
  }

  item.quantidade = quantidade;

  res.json({
    message: "Quantidade atualizada",
    cart: buildCartResponse(cart)
  });
}

function removeItem(req, res) {
  const productId = Number(req.params.productId);
  const cart = findUserCart(req.user.id);
  const index = cart.items.findIndex((item) => item.productId === productId);

  if (index === -1) {
    return res.status(404).json({
      message: "Item não encontrado no carrinho"
    });
  }

  cart.items.splice(index, 1);

  res.json({
    message: "Item removido do carrinho",
    cart: buildCartResponse(cart)
  });
}

module.exports = {
  findUserCart,
  buildCartResponse,
  getCart,
  addItem,
  updateItem,
  removeItem
};
