const bcrypt = require("bcryptjs");
const { users, nextId } = require("../data/store");
const publicUser = require("../utils/userPresenter");

async function register(req, res) {
  const { nome, email, senha, endereco } = req.body;

  const newUser = {
    id: nextId("user"),
    nome,
    email: email.toLowerCase(),
    senhaHash: await bcrypt.hash(senha, 10),
    endereco,
    isAdmin: false
  };

  users.push(newUser);

  res.status(201).json({
    message: "Usuário cadastrado com sucesso",
    user: publicUser(newUser)
  });
}

async function login(req, res) {
  const { email, senha } = req.body;
  const user = users.find((item) => item.email === email.toLowerCase());

  if (!user) {
    return res.status(401).json({
      message: "E-mail ou senha inválidos"
    });
  }

  const validPassword = await bcrypt.compare(senha, user.senhaHash);

  if (!validPassword) {
    return res.status(401).json({
      message: "E-mail ou senha inválidos"
    });
  }

  req.session.userId = user.id;

  res.json({
    message: "Login realizado com sucesso",
    user: publicUser(user)
  });
}

function logout(req, res) {
  req.session.destroy((error) => {
    if (error) {
      return res.status(500).json({
        message: "Erro ao encerrar sessão"
      });
    }

    res.clearCookie("connect.sid");

    res.json({
      message: "Logout realizado com sucesso"
    });
  });
}

function profile(req, res) {
  res.json({
    user: publicUser(req.user)
  });
}

function updateProfile(req, res) {
  const { nome, endereco, senha } = req.body;

  if (nome) {
    req.user.nome = nome;
  }

  if (endereco) {
    req.user.endereco = endereco;
  }

  if (senha) {
    req.user.senhaHash = bcrypt.hashSync(senha, 10);
  }

  res.json({
    message: "Perfil atualizado com sucesso",
    user: publicUser(req.user)
  });
}

module.exports = {
  register,
  login,
  logout,
  profile,
  updateProfile
};
